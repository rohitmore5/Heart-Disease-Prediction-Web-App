# Multiple-Disease-Prediction-Web-App
We built a multiple disease prediction system using machine learning in python. We also deployed this web app using Stramlit.

Problem statement where we worked - 
The International Diabetes Federation projects that the number of Indians with diabetes will soar to 123 million by 2040.  Currently, 5% of the Indian population suffers from diabetes.
According to the World Heath Organization, 28% of all deaths in India was related to heart disease.
Parkinson’s disease is a progressive disorder of the nervous system that affects movement. It is estimated that 10 million people have Parkinson’s disease worldwide, affecting all races and cultures. In India there are an estimated 1 Million people who suffer from Parkinson’s.
1 in 28 women in India was likely to develop breast cancer during her lifetime. A few decades back, breast cancer was seen only after fifty years of age and the number of young women suffering from this disease was lesser. Almost 65-70 per cent patients were above 50 years and only 30 to 35 per cent women were below 50 years.
The traditional way of diagnosis may not be sufficient in the case of a serious ailment. Developing a medical diagnosis system based on machine learning (ML) algorithms for prediction of any disease can help in a more accurate diagnosis than the conventional method. We have designed a multiple disease prediction system using multiple ML algorithms.
Lack of relevant assistive technology( assistive, adaptive, rehabilitative devices ).
Conventional diagnosis and prediction method is time consuming and costly.
Inconvenient scheduling.
Accurate and on-time analysis of any health-related problem is important for the prevention and treatment of the illness.




